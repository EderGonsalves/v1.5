"use client";

import { useState, useEffect } from "react";
import { useOnboarding } from "@/components/onboarding/onboarding-context";
import { Sidebar } from "@/components/Sidebar";
import { Header } from "@/components/Header";
import { useSidebar } from "@/components/sidebar/sidebar-context";
import { cn } from "@/lib/utils";

export function AppShell({ children }: { children: React.ReactNode }) {
  const { data } = useOnboarding();
  const { isCollapsed } = useSidebar();
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  const hasAuth = isMounted && data.auth;

  // Login page: no sidebar, no header, just render children full-width
  if (!hasAuth) {
    return <>{children}</>;
  }

  return (
    <div className="min-h-screen">
      <Sidebar />
      <div
        className={cn(
          "flex flex-col min-h-screen sidebar-transition",
          "lg:ml-[var(--sidebar-width)]",
          isCollapsed && "lg:ml-[var(--sidebar-width-collapsed)]"
        )}
      >
        <Header />
        <main className="flex-1">
          {children}
        </main>
      </div>
    </div>
  );
}
