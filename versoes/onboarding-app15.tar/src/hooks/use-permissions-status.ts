"use client";

import { useEffect, useState } from "react";

import { fetchPermissionsStatusClient } from "@/services/permissions-client";

export const usePermissionsStatus = (authSignature?: string | null) => {
  const [isSysAdmin, setIsSysAdmin] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    let active = true;

    if (!authSignature) {
      setIsSysAdmin(false);
      setIsLoading(false);
      return () => {
        active = false;
      };
    }

    setIsLoading(true);

    const load = async () => {
      try {
        const status = await fetchPermissionsStatusClient();
        if (active) {
          setIsSysAdmin(Boolean(status.isSysAdmin));
        }
      } catch (error) {
        console.warn("Não foi possível verificar status de permissões", error);
        if (active) {
          setIsSysAdmin(false);
        }
      } finally {
        if (active) {
          setIsLoading(false);
        }
      }
    };

    void load();

    return () => {
      active = false;
    };
  }, [authSignature]);

  return {
    isSysAdmin,
    isLoading,
  };
};
