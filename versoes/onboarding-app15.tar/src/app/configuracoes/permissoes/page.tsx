"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ShieldCheck,
  RefreshCw,
  Users,
  MenuSquare,
  Building2,
} from "lucide-react";

import { useOnboarding } from "@/components/onboarding/onboarding-context";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { LoadingScreen } from "@/components/ui/loading-screen";
import { usePermissionsAdmin } from "@/hooks/use-permissions-admin";
import { fetchInstitutionsClient } from "@/services/permissions-client";
import type { PermissionsOverview } from "@/services/permissions";

const buildMenuPath = (
  menuId: number | null | undefined,
  menuMap: Map<number, PermissionsOverview["menus"][number]>,
) => {
  if (!menuId) {
    return "Menu não associado";
  }

  const chain: string[] = [];
  let current = menuMap.get(menuId);

  while (current) {
    chain.unshift(current.label ?? `Menu #${current.id}`);
    if (!current.parentId) break;
    current = menuMap.get(current.parentId);
  }

  return chain.join(" / ");
};

export default function PermissionsAdminPage() {
  const { data, isHydrated } = useOnboarding();
  const authSignature = data.auth
    ? `${data.auth.institutionId}:${data.auth.legacyUserId ?? ""}`
    : null;

  const [selectedInstitutionId, setSelectedInstitutionId] = useState<
    number | undefined
  >(undefined);
  const [institutions, setInstitutions] = useState<
    Array<{ institutionId: number; userCount: number }>
  >([]);
  const [loadingInstitutions, setLoadingInstitutions] = useState(false);

  const {
    overview,
    usersWithRoles,
    isLoading,
    isSysAdmin,
    isGlobalAdmin,
    error,
    refresh,
    updateRolePermissions,
    updateUserRoles,
    isRoleUpdating,
    isUserUpdating,
  } = usePermissionsAdmin(authSignature, selectedInstitutionId);

  // Load institution list for global admin
  useEffect(() => {
    if (!data.auth || data.auth.institutionId !== 4) return;

    let active = true;
    setLoadingInstitutions(true);

    fetchInstitutionsClient()
      .then((list) => {
        if (active) setInstitutions(list);
      })
      .catch((err) => {
        console.warn("Erro ao carregar instituições:", err);
      })
      .finally(() => {
        if (active) setLoadingInstitutions(false);
      });

    return () => {
      active = false;
    };
  }, [data.auth]);

  const menuMap = useMemo(() => {
    const map = new Map<number, PermissionsOverview["menus"][number]>();
    if (!overview) return map;
    for (const menu of overview.menus) {
      map.set(menu.id, menu);
    }
    return map;
  }, [overview]);

  const permissionOptions = useMemo(() => {
    if (!overview) return [];
    return overview.permissions.map((permission) => {
      const menuLabel = buildMenuPath(permission.menuId ?? null, menuMap);
      return {
        id: permission.id,
        code: permission.code,
        description: permission.description,
        menuLabel,
      };
    });
  }, [overview, menuMap]);

  const { menusWithPermissions, orphanPermissions } = useMemo(() => {
    if (!overview) {
      return {
        menusWithPermissions: [] as Array<
          PermissionsOverview["menus"][number] & {
            menuPath: string;
            permissions: PermissionsOverview["permissions"][number][];
          }
        >,
        orphanPermissions: [] as PermissionsOverview["permissions"][number][],
      };
    }

    const permsByMenu = overview.permissions.reduce(
      (acc, perm) => {
        const menuId = perm.menuId ?? 0;
        const list = acc.get(menuId) ?? [];
        list.push(perm);
        acc.set(menuId, list);
        return acc;
      },
      new Map<number, PermissionsOverview["permissions"][number][]>(),
    );

    return {
      menusWithPermissions: overview.menus.map((menu) => ({
        ...menu,
        menuPath: buildMenuPath(menu.id, menuMap),
        permissions: permsByMenu.get(menu.id) ?? [],
      })),
      orphanPermissions: permsByMenu.get(0) ?? [],
    };
  }, [overview, menuMap]);

  const handleToggleRolePermission = useCallback(
    (roleId: number, permissionId: number, checked: boolean) => {
      if (!overview) return;
      const role = overview.roles.find((entry) => entry.id === roleId);
      if (!role) return;

      const next = new Set(role.permissionIds);
      if (checked) {
        next.add(permissionId);
      } else {
        next.delete(permissionId);
      }

      void updateRolePermissions(roleId, Array.from(next));
    },
    [overview, updateRolePermissions],
  );

  const handleToggleUserRole = useCallback(
    (userId: number, roleId: number, checked: boolean) => {
      const user = usersWithRoles.find((entry) => entry.id === userId);
      if (!user) return;

      const next = new Set(user.roleIds);
      if (checked) {
        next.add(roleId);
      } else {
        next.delete(roleId);
      }

      void updateUserRoles(userId, Array.from(next));
    },
    [usersWithRoles, updateUserRoles],
  );

  if (!isHydrated || !data.auth) {
    return <LoadingScreen message="Validando sessão..." />;
  }

  if (isLoading && !overview) {
    return <LoadingScreen message="Carregando permissões..." />;
  }

  if (!isLoading && !isSysAdmin) {
    return (
      <main className="min-h-screen bg-background py-10">
        <div className="mx-auto max-w-4xl space-y-4 rounded-xl border border-border/70 bg-card p-8 text-center shadow">
          <ShieldCheck className="mx-auto mb-3 h-12 w-12 text-muted-foreground" />
          <h1 className="text-xl font-semibold text-foreground">
            Acesso restrito
          </h1>
          <p className="text-sm text-muted-foreground">
            Apenas o usuário SysAdmin pode acessar a configuração de menus e
            permissões.
          </p>
        </div>
      </main>
    );
  }

  const displayInstitutionId =
    overview?.targetInstitutionId ?? data.auth.institutionId;

  return (
    <main className="min-h-screen bg-background py-8">
      <div className="mx-auto flex max-w-6xl flex-col gap-6 px-4">
        {/* Institution selector - only for global admin */}
        {isGlobalAdmin && institutions.length > 0 && (
          <div className="flex flex-col gap-3 rounded-2xl border border-primary/30 bg-primary/5 p-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-3">
              <Building2 className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm font-semibold text-foreground">
                  Admin Global
                </p>
                <p className="text-xs text-muted-foreground">
                  Selecione a instituição para gerenciar
                </p>
              </div>
            </div>
            <select
              value={selectedInstitutionId ?? ""}
              onChange={(e) => {
                const val = e.target.value;
                setSelectedInstitutionId(val ? Number(val) : undefined);
              }}
              className="rounded-lg border border-border bg-background px-3 py-2 text-sm text-foreground"
              disabled={loadingInstitutions}
            >
              <option value="">
                Minha instituição ({data.auth.institutionId})
              </option>
              {institutions
                .filter((i) => i.institutionId !== data.auth!.institutionId)
                .map((inst) => (
                  <option key={inst.institutionId} value={inst.institutionId}>
                    Instituição {inst.institutionId} ({inst.userCount}{" "}
                    {inst.userCount === 1 ? "usuário" : "usuários"})
                  </option>
                ))}
            </select>
          </div>
        )}

        <div className="flex flex-col gap-4 rounded-2xl border border-border/70 bg-card/90 p-6 shadow-sm lg:flex-row lg:items-center lg:justify-between">
          <div className="space-y-2">
            <p className="text-sm font-medium uppercase tracking-wide text-muted-foreground">
              Controles de acesso
              {selectedInstitutionId
                ? ` — Instituição ${displayInstitutionId}`
                : ""}
            </p>
            <h1 className="text-2xl font-semibold text-foreground">
              Menus e permissões da agenda
            </h1>
            <p className="text-sm text-muted-foreground">
              Defina quais funcionalidades ficam visíveis para cada perfil e
              atribua os perfis corretos para cada usuário sincronizado.
            </p>
          </div>
          <div className="flex flex-col gap-3 sm:flex-row">
            <Button
              variant="outline"
              onClick={() => refresh()}
              disabled={isLoading}
              className="gap-2"
            >
              <RefreshCw className="h-4 w-4" />
              Atualizar dados
            </Button>
            <div className="flex items-center gap-2 rounded-lg border border-emerald-500/50 bg-emerald-50 px-3 py-2 text-sm text-emerald-800">
              <ShieldCheck className="h-4 w-4" />
              <span>
                {isGlobalAdmin ? "Admin Global" : "SysAdmin"} autenticado
              </span>
            </div>
          </div>
        </div>

        {error ? (
          <div className="rounded-lg border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm text-destructive">
            {error}
          </div>
        ) : null}

        <Card>
          <CardHeader className="flex flex-col gap-2 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex items-center gap-3">
              <ShieldCheck className="h-6 w-6 text-primary" />
              <div>
                <CardTitle>Perfis e permissões</CardTitle>
                <p className="text-sm text-muted-foreground">
                  Marque quais menus cada perfil pode acessar.
                </p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {!overview?.roles.length ? (
              <p className="text-sm text-muted-foreground">
                Nenhum perfil cadastrado.
              </p>
            ) : (
              overview.roles.map((role) => (
                <div
                  key={role.id}
                  className="rounded-xl border border-border/60 bg-muted/20 p-4"
                >
                  <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <p className="text-base font-semibold text-foreground">
                        {role.name}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {role.description || "Sem descrição"}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <span className="rounded-full border border-primary/30 px-2 py-0.5 uppercase tracking-wide text-primary">
                        {role.isSystem ? "Sistema" : "Customizado"}
                      </span>
                      {isRoleUpdating(role.id) && (
                        <span className="animate-pulse text-primary">
                          Salvando...
                        </span>
                      )}
                    </div>
                  </div>
                  <Separator className="my-4" />
                  <div className="grid gap-3 md:grid-cols-2">
                    {permissionOptions.map((permission) => (
                      <label
                        key={permission.id}
                        className="flex items-start gap-3 rounded-lg border border-border/40 bg-background px-3 py-2 text-sm"
                      >
                        <Checkbox
                          checked={role.permissionIds.includes(permission.id)}
                          onCheckedChange={(checked) =>
                            handleToggleRolePermission(
                              role.id,
                              permission.id,
                              Boolean(checked),
                            )
                          }
                          disabled={isRoleUpdating(role.id)}
                          className="mt-1"
                        />
                        <div className="space-y-1">
                          <p className="font-medium text-foreground">
                            {permission.menuLabel}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {permission.code} •{" "}
                            {permission.description || "Sem descrição"}
                          </p>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-col gap-2 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex items-center gap-3">
              <Users className="h-6 w-6 text-primary" />
              <div>
                <CardTitle>Usuários e perfis</CardTitle>
                <p className="text-sm text-muted-foreground">
                  Determine quais perfis cada usuário sincronizado possui.
                </p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {!usersWithRoles.length ? (
              <p className="text-sm text-muted-foreground">
                Nenhum usuário sincronizado com o Baserow até o momento.
              </p>
            ) : (
              usersWithRoles.map((user) => (
                <div
                  key={user.id}
                  className="rounded-xl border border-border/60 bg-muted/20 p-4"
                >
                  <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <p className="text-base font-semibold text-foreground">
                        {user.name || user.email}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {user.email || "sem e-mail"} • legacyID:{" "}
                        {user.legacyUserId || "não sincronizado"}
                      </p>
                    </div>
                    {isUserUpdating(user.id) && (
                      <span className="text-xs text-primary">Salvando...</span>
                    )}
                  </div>
                  <Separator className="my-4" />
                  <div className="grid gap-3 md:grid-cols-2">
                    {overview?.roles.map((role) => (
                      <label
                        key={role.id}
                        className="flex items-center gap-3 rounded-lg border border-border/40 bg-background px-3 py-2 text-sm"
                      >
                        <Checkbox
                          checked={user.roleIds.includes(role.id)}
                          onCheckedChange={(checked) =>
                            handleToggleUserRole(
                              user.id,
                              role.id,
                              Boolean(checked),
                            )
                          }
                          disabled={isUserUpdating(user.id)}
                        />
                        <div>
                          <p className="font-medium text-foreground">
                            {role.name}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {role.description || "Sem descrição"}
                          </p>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-col gap-2 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex items-center gap-3">
              <MenuSquare className="h-6 w-6 text-primary" />
              <div>
                <CardTitle>Menus cadastrados</CardTitle>
                <p className="text-sm text-muted-foreground">
                  Referência rápida dos caminhos configurados no Baserow.
                </p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {!menusWithPermissions.length ? (
              <p className="text-sm text-muted-foreground">
                Nenhum menu configurado.
              </p>
            ) : (
              menusWithPermissions.map((menu) => (
                <div
                  key={menu.id}
                  className="rounded-xl border border-border/60 bg-background px-4 py-3"
                >
                  <div className="flex flex-col gap-1 md:flex-row md:items-center md:justify-between">
                    <div>
                      <p className="text-sm font-semibold text-foreground">
                        {menu.label}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {menu.menuPath || menu.path || "Sem rota definida"}
                      </p>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {menu.isActive ? "Ativo" : "Inativo"}
                    </div>
                  </div>
                  {menu.permissions.length ? (
                    <div className="mt-3 text-xs text-muted-foreground">
                      Permissões:{" "}
                      {menu.permissions
                        .map((perm) => perm.code)
                        .join(", ")}
                    </div>
                  ) : null}
                </div>
              ))
            )}
            {orphanPermissions.length ? (
              <div className="rounded-xl border border-border/60 bg-amber-50 px-4 py-3 text-sm text-amber-900">
                <p className="font-semibold">Permissões sem menu vinculado</p>
                <p className="text-xs text-muted-foreground">
                  Ajuste-as no Baserow para que apareçam na lista de menus.
                </p>
                <ul className="mt-2 list-disc space-y-1 pl-5">
                  {orphanPermissions.map((perm) => (
                    <li key={perm.id}>
                      <span className="font-medium">{perm.code}</span> —{" "}
                      {perm.description || "Sem descrição"}
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
          </CardContent>
        </Card>
      </div>
    </main>
  );
}
